#!/usr/bin/env sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
mkdir -p build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build main.tex > build/pass1.console.txt 2>&1
(
  cd build
  BIBINPUTS=../: BSTINPUTS=../: bibtex main > bibtex.console.txt 2>&1
)
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build main.tex > build/pass2.console.txt 2>&1
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build main.tex > build/pass3.console.txt 2>&1
cp build/main.pdf main.pdf
cp build/main.bbl main.bbl
printf 'Built main.pdf\n'
