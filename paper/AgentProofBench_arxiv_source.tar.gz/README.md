# AgentProofBench arXiv manuscript

**AgentProofBench: Reusable Verifiers for Web Agents**

Authors, in order: Jingjie Ning, Xueqi Li, Yi Lu, and Yibo Kong. All authors are affiliated with the School of Computer Science, Carnegie Mellon University. Jingjie Ning is the corresponding author: [jening@cs.cmu.edu](mailto:jening@cs.cmu.edu).

The named manuscript has **12 pages**, including references and appendices. It preserves the scientific text, numerical definitions, 32 references, and all ten result/diagram assets from the current WWW manuscript. The arXiv adaptation changes the title block, removes anonymous-review and conference metadata, and calls the resource the “companion” instead of the “anonymous companion.”

The first page includes clickable vector buttons for the [project page](https://ethanning.github.io/AgentProofBench/) and [GitHub repository](https://github.com/EthanNing/AgentProofBench). All paper figures and the main result table are vector PDFs with embedded fonts.

## Files

- `main.tex`, `main.pdf`: manuscript source and compiled paper.
- `main.bbl`, `references.bib`: compiled bibliography and editable bibliography source.
- `acmart.cls`, `ACM-Reference-Format.bst`: the class and bibliography style used for this build.
- `revision_results.tex`, `scope_results_p1.tex`, `scope_results_p2.tex`, `strengthening_results.tex`: numerical definitions.
- `figures/`, `tables/`: local vector assets; every manuscript dependency is inside this directory.
- `AgentProofBench_arxiv_source.tar.gz`: independently compiled source package; excludes the compiled manuscript PDF, build intermediates, and previews.
- `build/`: local compilation and validation outputs; excluded from the source package.

## Build

Use a standard TeX Live installation containing pdfLaTeX, BibTeX, and TikZ:

```sh
sh build.sh
```

The command builds `main.pdf` and refreshes `main.bbl`. The source archive includes both the bibliography source and the generated `.bbl`. It requires no project checkout, network access, figure regeneration, model calls, or experiment execution.

The manuscript uses `acmart` in `sigconf,nonacm` mode with a compact shared affiliation. The included class retains its original license notice. The GitHub icon is a vector asset; its MIT notice is in `figures/github-logo-LICENSE.txt`.

This directory contains locally prepared manuscript artifacts. No arXiv submission or manuscript-license selection was performed.
